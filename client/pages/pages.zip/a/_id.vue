<template>
  <RoomAuto/>
</template>
