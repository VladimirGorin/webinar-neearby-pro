<template>
  <CreateAutoWebinarForm/>
</template>
